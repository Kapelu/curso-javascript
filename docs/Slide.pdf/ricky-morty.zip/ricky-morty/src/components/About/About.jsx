import style from "./About.module.css";

const About = () => {
    return(
        <div className={style.container} >
            <h1>Esta es la App de la Kapelu</h1>
            <h2>Cohorte: Ft-36</h2>
        </div>
    )
}

export default About;